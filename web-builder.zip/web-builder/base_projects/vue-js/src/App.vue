<template>
    <RouterView />
</template>