Framework: {{FRAMEWORK}}
Language: {{LANGUAGE}}

Add routing for following pages:
{{PAGE_ROUTES}}
Tell me which files need to be updated or created to setup routing.
