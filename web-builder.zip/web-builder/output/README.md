# Output Directory

This directory contains generated projects:

- `projects/` - Generated project folders
- `zips/` - Packaged project zip files

Files in this directory are automatically created by the application.
